<template>
  <div class="list-main main">
    <div class="right">Edit</div><strong>Recent Transactions</strong> 
    <div id="transaction-list" class="box">
      <ListRow
        v-for="(row, key) in transactionData"
        :key="key"
        :k="key"
        :row="row" />
    <br clear="all" />
    <div class="left" style="margin-left: 76%; height: 20px;">Total: ${{ total }}</div>
    <br clear="all" />


    </div>
  </div>
</template>

<script>
  import axios from 'axios';
  import ListRow from '../components/ListRow.vue';
  export default {
    name: 'ListMain',
    components: {
      ListRow
    },
    data() {
      return {
        transactionData: {}
      };
    },
    async created() {
      const result = await axios.get("/api/transactions");
      // const transactionData = result.data;
      this.transactionData = result.data;

      var date = null;
      this.total = 0;
      for(var k in this.transactionData) {
        date = new Date(this.transactionData[k].time * 1000)
        this.transactionData[k].date = date.toLocaleDateString();
        var amt = parseFloat(this.transactionData[k].amt) * 100;
        this.total += (this.transactionData[k].type === 0) ? amt : -amt;
      }
      this.total = (this.total/100).toFixed(2);
    }
  };
</script>

