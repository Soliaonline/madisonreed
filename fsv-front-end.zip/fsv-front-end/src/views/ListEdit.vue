<template>
  <div class="list-edit main">
    <div class="box">
      <form @submit.prevent="handleSubmit" autocomplete="off">
        Date
        <Datepicker v-model="formData.time" name="time"></Datepicker><br>
        Description
        <textarea v-model="formData.desc" name="desc" style="padding: 6px;" placeholder="Visit Description"></textarea>
        <br><br>
        <div class="left">
          Amount
          <div style="position: relative;">
            <label>$</label>
            <input v-model="formData.amt" type="text" name="amount" style="text-indent: 30px;" placeholder="0.00" />
          </div>
        </div>
        <div class="left">
          Refunded or Debit?
          <div style="position: relative;">
            <input v-model="formData.type" v-bind:true-value="1" v-bind:false-value="0" :value="1" name="debit" type="checkbox" />
          </div>
        </div>
        <br clear="all" />

        <div class="inline" style="width: 50%; padding: 5px;">
          <input v-on:click="toList();" class="pointer" type="button" value="Cancel" />
        </div>
        <div class="inline" style="width: 50%; padding: 5px;">
          <input class="pointer" type="submit" value="Submit" />
        </div>
      </form>
    </div>
  </div>
</template>

<script>
    import Datepicker from '@vuepic/vue-datepicker';
    import '@vuepic/vue-datepicker/dist/main.css';
    import axios from 'axios';
    var formData = {
            time: 0,
            amt: "",
            desc: "",
            type: 0
          };

    export default {
        name: 'ListEdit',
        components: { Datepicker },
        data() {
          return {
            formData
          };
        },
        async created() {
          if(this.$route.params.id) {
            if(parseInt(this.$route.params.id) === 0) { // Valid ID not sent
              this.redirectToZero();
              return;
            }

            const result = await axios.get("/api/transaction/" + this.$route.params.id);
            this.formData = result.data;
            if(!this.formData || !Object.keys(this.formData).length) {
              this.redirectToZero();
              return;
            }
            this.formData.time = new Date(this.formData.time*1000);
          }
        },
        methods: {
          redirectToZero() {
            console.log('Redirect to Zero');
            this.$router.push({ name: 'edit', params: { id: 0 }});
          },
          toList() {
            this.$router.push({ name: 'list'});
          },
          async handleSubmit(event) {
            event.preventDefault();

            this.formData.amt = parseFloat(this.formData.amt) * 100 

            if(this.formData.amt < 0) {
              alert('Amount must be positive, if this is a debit please check the debit box.');
              return;
            }

            if(this.formData.time < 1357016400) { // First day of 2013, the year the Madison-Reed opened.
              alert('The time cannot be older than the company itself, please select a valid date.');
            }

            // garantee 2 decimal places.
            this.formData.amt = (this.formData.amt / 100).toFixed(2);
            formData = {
              "time": (this.formData.time.getTime()/1000),
              "desc": this.formData.desc,
              "amt": this.formData.amt,
              "type": (this.formData.type) ? 1: 0
            }

            const result = await axios.post("/api/transaction/edit/" + this.$route.params.id, formData, {
              headers: {
                'Content-Type': 'application/json'
              }
            });
            if(result) {
              this.toList();
            }
          }
        }
    };
</script>

<style scoped>
  .left {
    width: 50%;
  }
  textarea, input {
    outline: none;
    border-style:solid;
    border-color: #ddd;
    width: 100%;
    border-radius: 5px;
    font-size: 1rem;
    color: #212121;
    font-family: "Segoe UI", roboto, oxygen, ubuntu, cantarell, "Open Sans", "Helvetica Neue", sans-serif;
  }
  label {
    font-family: "Segoe UI", roboto, oxygen, ubuntu, cantarell, "Open Sans", "Helvetica Neue", sans-serif;
    position: absolute;
    left: 15px;
    line-height: 37px;
    font-size: 1rem;
  }
  input {
    height: 37px;
    padding: 3px;
  }
</style>