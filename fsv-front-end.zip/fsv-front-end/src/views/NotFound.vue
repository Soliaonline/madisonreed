<template>
    <div class="main">
        <h1>These are not the droids you seek.</h1>
    </div>
</template>
  
<script>
    export default {
        name: 'NotFound',
    };
</script>

<style scoped>
    h1 {
        color: #0000ff;
    }
</style>