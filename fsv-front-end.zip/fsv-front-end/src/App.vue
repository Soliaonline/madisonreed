<template>
  <nav>
    <router-link to="/list">List</router-link>
    <router-link to="/list/edit/0">Add Transaction</router-link>
  </nav>
  <router-view/>
</template>

<style>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
  }

  nav {
    padding: 30px;
    border-bottom: solid 1px #999999;
    font-family: 'Averta-Regular',sans-serif;
    font-weight: normal;
    font-style: normal;
    color: #343434;
    background-color: #fff;
    font-size: 14px;
    letter-spacing: .13em;
    text-align: center;
    vertical-align: middle;
    text-transform: uppercase;
    white-space: nowrap;
    cursor: pointer;
    overflow: visible;
    text-decoration: none;
  }

  nav a {
    padding: 30px;
    font-weight: bold;
    color: #2c3e50;
    text-decoration: none;
  }

  nav a.router-link-exact-active {
    color: #911885;
  }

  .main {
    background-color: #FBFBFB;
    font-family: 'Averta-Regular',sans-serif;
    letter-spacing: .03em;
    min-height: 400px;
    padding: 10px;
  }

  .box {
    border: solid 1px #666;
    background-color: #F0F0F0;
    padding: 10px;
  }

  * {
    box-sizing: border-box;
  }

  .font-left  {
    text-align: left;
  }
  .font-right  {
    text-align: right;
  }
  .left {
    float: left;
  }
  .right {
    float: right;
  }

  .inline {
    display: inline-block;
  }

  .pointer {
    cursor: pointer;
  }
</style>
