<template>
  <div class="row">
      <div class="left" style="width: 20%;">{{ row.date }} :</div>
      <div class="left list-desc" style="width: 60%;">{{ row.desc }}</div>
      <div v-if="row.type === 0" class="left" style="width: 10%;">${{ row.amt }}</div>
      <div v-else class="left negative" style="width: 10%;">${{ row.amt }}</div>
      <router-link :to="'/list/edit/' + k">
          <div class="right edit"><img src="../assets/pencil.svg"></div>
      </router-link>
  </div>
</template>

<script>
  export default {
      name: 'ListRow',
      props: ['row', 'k']
  }
</script>

<style scoped>
.row {
  padding: 10px 4px;
  height: 36px;
}
.list-desc {
  text-wrap: no-wrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
#transaction-list > .row:nth-child(odd) {
  background-color: rgba(255,255,255,0.5);
}
.row > .edit img {
  height: 20px;
  width: 20px;
  cursor: pointer;
}
.negative {
  color: #CC0000;
}
</style>