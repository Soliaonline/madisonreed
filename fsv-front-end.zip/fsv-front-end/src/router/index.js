import { createRouter, createWebHistory } from 'vue-router'
import ListMainPage from '../views/ListMain.vue';
import ListEditPage from '../views/ListEdit.vue';
import NotFound from '../views/NotFound.vue';

const routes = [
  {
    path: '/list',
    name: 'list',
    component: ListMainPage
  },
  {
    path: '/list/edit/:id',
    name: 'edit',
    component: ListEditPage
  },
  {
    path: '/',
    redirect: '/list'
  },
  { 
    path: '/404', 
    component: NotFound 
  },
  {
    path: '/:catchAll(.*)',
    redirect:'404'
  },  
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
