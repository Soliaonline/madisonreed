import { shallowMount } from '@vue/test-utils';
import { mount } from '@vue/test-utils';
import ListMain from '@/views/ListMain.vue';
import ListEdit from '@/views/ListEdit.vue';

describe('ListMain.vue', () => {
  test('if Total Renders', () => {
    const wrapper = shallowMount(ListMain);
    expect(wrapper.html()).toContain('Total: $');
  });

  test("if Image Loads", () => {
    const wrapper = mount(ListMain);
    expect(wrapper.find("img")).toBe(true);
  });
});